import math
import time
import random
import numpy as np
import matplotlib.pyplot as plt
from dataclasses import dataclass, field
from typing import List, Tuple, Optional, Dict

# --- 1. World / Units Configuration (Constants) ---
FT_TO_MM = 304.8
FEET_TO_PX = 50       # 1 ft = 50 px
WORLD_FT = 15.0
WORLD_PX = int(WORLD_FT * FEET_TO_PX)  # 750 px

NUM_SAMPLES = 240
DEG_PER_SAMPLE = 360.0 / NUM_SAMPLES  # 1.5Â°

# Training constants
EPISODE_STEPS = 1200  # Equivalent to 20 seconds at ~60 FPS
DT = 1.0 / 60.0      # Time step for physics update

# The overall training run will NOT stop early, but we will track when the target is achieved.
TARGET_WEIGHTED_SCORE = 0.700 

# --- EPISODE FAILURE CONDITION ---
# The individual episode simulation will terminate early if the cumulative reward 
# drops below this threshold (e.g., agent is stuck or continuously colliding).
EPISODE_CUMULATIVE_REWARD_THRESHOLD = -50.0

# --- 2. SHAPES CONFIG (The Environment) ---
SHAPES_CONFIG = {
    "rectangles": [
        {"cx_ft": 7.5, "cy_ft": 10.0, "w_ft": 3.0, "h_ft": 1.5},
        {"cx_ft": 5.0,  "cy_ft": 6.0,  "w_ft": 2.0, "h_ft": 2.0},
    ],
    "circles": [
        {"cx_ft": 10.0, "cy_ft": 5.0, "r_ft": 1.0},
    ],
}

# --- 3. Geometry Primitives & World (Headless) ---
Point = Tuple[float, float]
Segment = Tuple[Point, Point]

@dataclass
class Rectangle:
    cx: float; cy: float; w: float; h: float
    def segments(self) -> List[Segment]:
        x0 = self.cx - self.w/2.0; x1 = self.cx + self.w/2.0
        y0 = self.cy - self.h/2.0; y1 = self.cy + self.h/2.0
        return [((x0,y0),(x1,y1)), ((x1,y0),(x0,y1))]

@dataclass
class Circle:
    cx: float; cy: float; r: float

@dataclass
class World:
    size_px: int = WORLD_PX
    lidar_pos: Point = field(default_factory=lambda: (WORLD_PX/2, WORLD_PX/2))
    lidar_heading_deg: float = -90.0
    rectangles: List[Rectangle] = field(default_factory=list)
    circles: List[Circle] = field(default_factory=list)

    def wall_segments(self) -> List[Segment]:
        s = self.size_px
        return [((0,0),(s,0)), ((s,0),(s,s)), ((s,s),(0,s)), ((0,s),(0,0))]

    def all_segments(self) -> List[Segment]:
        segs = list(self.wall_segments())
        for r in self.rectangles:
            segs.extend(r.segments())
        return segs

def ray_segment_intersection(ray_o: Point, ray_d: Point, p0: Point, p1: Point) -> Optional[float]:
    """Intersection logic for ray vs. line segment."""
    ox, oy = ray_o; dx, dy = ray_d
    x1, y1 = p0; x2, y2 = p1
    vx, vy = x2 - x1, y2 - y1
    denom = dx * (-vy) + dy * (vx)
    if abs(denom) < 1e-9: return None
    rx, ry = x1 - ox, y1 - oy
    t = (rx * (-vy) + ry * (vx)) / denom
    if t < 0: return None
    ix, iy = ox + t*dx, oy + t*dy
    segment_len_sq = vx*vx + vy*vy
    if segment_len_sq < 1e-9: return None
    
    dot_product = (ix - x1)*(x2 - x1) + (iy - y1)*(y2 - y1)
    segment_len_sq_check = (x2 - x1)**2 + (y2 - y1)**2
    
    if segment_len_sq_check > 1e-9:
        u = dot_product / segment_len_sq_check
        if u < -1e-9 or u > 1.0 + 1e-9:
            return None
    elif dot_product != 0:
        return None 
    
    return t

def ray_circle_intersection(ray_o: Point, ray_d: Point, center: Point, r: float) -> Optional[float]:
    """Intersection logic for ray vs. circle."""
    ox, oy = ray_o; dx, dy = ray_d
    cx, cy = center
    fx, fy = ox - cx, oy - cy
    a = dx*dx + dy*dy
    b = 2*(fx*dx + fy*dy)
    c = fx*fx + fy*fy - r*r
    disc = b*b - 4*a*c
    if disc < 0: return None
    sqrt_disc = math.sqrt(disc)
    t1 = (-b - sqrt_disc) / (2*a)
    t2 = (-b + sqrt_disc) / (2*a)
    ts = [t for t in (t1, t2) if t >= 0]
    if not ts: return None
    return min(ts)

def simulate_frame(world: World) -> List[int]:
    """Return 240 distances in millimeters."""
    lx, ly = world.lidar_pos
    distances_px: List[float] = [0.0]*NUM_SAMPLES
    segs = world.all_segments()

    for i in range(NUM_SAMPLES):
        angle_deg = world.lidar_heading_deg - i*DEG_PER_SAMPLE
        th = math.radians(angle_deg)
        dx, dy = math.cos(th), math.sin(th)
        best_t: Optional[float] = None

        for p0, p1 in segs:
            t = ray_segment_intersection((lx,ly), (dx,dy), p0, p1)
            if t is not None and (best_t is None or t < best_t): best_t = t

        for c in world.circles:
            t = ray_circle_intersection((lx,ly), (dx,dy), (c.cx,c.cy), c.r)
            if t is not None and (best_t is None or t < best_t): best_t = t

        if best_t is None: best_t = WORLD_PX * 2.0
        distances_px[i] = best_t

    px_to_mm = (1.0 / FEET_TO_PX) * FT_TO_MM
    distances_mm = [int(round(d * px_to_mm)) for d in distances_px]
    return distances_mm

# --- 4. OPTIMIZED Neural Network Implementation (NumPy) ---

def he_init(fan_in, fan_out):
    """He initialization for better gradient flow with ReLU-like activations"""
    return np.random.randn(fan_in, fan_out) * np.sqrt(2.0 / fan_in)

def leaky_relu(x, alpha=0.01):
    """Leaky ReLU prevents dying neurons"""
    return np.where(x > 0, x, alpha * x)

def leaky_relu_derivative(x, alpha=0.01):
    """Derivative of Leaky ReLU"""
    return np.where(x > 0, 1.0, alpha)

class NeuralNetwork:
    def __init__(self, input_size, hidden_size, output_size):
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.output_size = output_size
        
        # He initialization for better gradient flow
        self.W1 = he_init(self.input_size, self.hidden_size)
        self.b1 = np.zeros((1, self.hidden_size))
        self.W2 = he_init(self.hidden_size, self.output_size)
        self.b2 = np.zeros((1, self.output_size))
        
        # Momentum terms for faster convergence
        self.v_W1 = np.zeros_like(self.W1)
        self.v_b1 = np.zeros_like(self.b1)
        self.v_W2 = np.zeros_like(self.W2)
        self.v_b2 = np.zeros_like(self.b2)
        
    def forward(self, X):
        """Forward pass with Leaky ReLU"""
        self.z1 = np.dot(X, self.W1) + self.b1
        self.a1 = leaky_relu(self.z1)
        self.z2 = np.dot(self.a1, self.W2) + self.b2
        self.a2 = np.tanh(self.z2)
        return self.a2
    
    def get_action(self, state: List[int]) -> Tuple[float, float]:
        """Runs a forward pass and converts output to practical movement values."""
        X = np.array(state, dtype=np.float32).reshape(1, -1)
        X_norm = X / 10000.0
        
        output = self.forward(X_norm)
        
        turn_rate = output[0, 0] * 45.0
        forward_speed_px = (output[0, 1] + 1.0) / 2.0 * 300.0
        
        return float(turn_rate), float(forward_speed_px)

    def backward_batch(self, X_batch, Y_batch, advantages, learning_rate, momentum=0.9, gradient_clip=1.0):
        """
        OPTIMIZED: Vectorized batch backpropagation with momentum and gradient clipping.
        Much faster than per-sample updates.
        """
        batch_size = X_batch.shape[0]
        
        # Normalize inputs
        X_norm = X_batch / 10000.0
        
        # Forward pass
        z1 = np.dot(X_norm, self.W1) + self.b1
        a1 = leaky_relu(z1)
        z2 = np.dot(a1, self.W2) + self.b2
        a2 = np.tanh(z2)
        
        # Backward pass - VECTORIZED for entire batch
        error = Y_batch - a2
        
        # Weight advantages by reshaping to (batch_size, 1)
        advantages_reshaped = advantages.reshape(-1, 1)
        d_output = error * (1.0 - a2**2) * advantages_reshaped
        
        # Gradients for W2 and b2
        d_W2 = np.dot(a1.T, d_output) / batch_size
        d_b2 = np.sum(d_output, axis=0, keepdims=True) / batch_size
        
        # Backpropagate to hidden layer
        d_hidden = np.dot(d_output, self.W2.T) * leaky_relu_derivative(z1)
        
        # Gradients for W1 and b1
        d_W1 = np.dot(X_norm.T, d_hidden) / batch_size
        d_b1 = np.sum(d_hidden, axis=0, keepdims=True) / batch_size
        
        # Gradient clipping for stability
        d_W1 = np.clip(d_W1, -gradient_clip, gradient_clip)
        d_b1 = np.clip(d_b1, -gradient_clip, gradient_clip)
        d_W2 = np.clip(d_W2, -gradient_clip, gradient_clip)
        d_b2 = np.clip(d_b2, -gradient_clip, gradient_clip)
        
        # Momentum updates (smooths gradient descent)
        self.v_W1 = momentum * self.v_W1 + learning_rate * d_W1
        self.v_b1 = momentum * self.v_b1 + learning_rate * d_b1
        self.v_W2 = momentum * self.v_W2 + learning_rate * d_W2
        self.v_b2 = momentum * self.v_b2 + learning_rate * d_b2
        
        # Apply updates
        self.W1 += self.v_W1
        self.b1 += self.v_b1
        self.W2 += self.v_W2
        self.b2 += self.v_b2

# --- 5. Mapper/Agent Class (Headless) ---
LIDAR_RADIUS = 10
WALL_THICKNESS = 6

class Mapper:
    GRID_CELL_SIZE_PX = 12.5 
    WORLD_GRID_W = int(WORLD_PX // GRID_CELL_SIZE_PX)
    WORLD_GRID_H = int(WORLD_PX // GRID_CELL_SIZE_PX)
    
    def __init__(self, initial_world: World):
        self.world = initial_world
        self.occupied_cells: set[Tuple[int, int]] = set() 
        self.episode_data: List[Tuple[np.ndarray, np.ndarray, float]] = [] 
        self.move_speed_px = 180.0
        self.wall_follow_distance_mm = 600.0
        
        self.ground_truth_cells: set[Tuple[int, int]] = self._generate_ground_truth_map()
        
    def reset(self, world_state: World):
        """Reverts the internal state and map for a new episode."""
        self.world = world_state
        self.occupied_cells.clear()
        self.episode_data.clear()

    def _px_to_grid(self, x_px: float, y_px: float) -> Optional[Tuple[int, int]]:
        i = int(y_px // self.GRID_CELL_SIZE_PX); j = int(x_px // self.GRID_CELL_SIZE_PX)
        if 0 <= i < self.WORLD_GRID_H and 0 <= j < self.WORLD_GRID_W:
            return i, j
        return None
    
    def _generate_ground_truth_map(self) -> set[Tuple[int, int]]:
        ground_truth: set[Tuple[int, int]] = set()
        for seg in self.world.all_segments():
            p0, p1 = seg; x0, y0 = p0; x1, y1 = p1
            length_px = math.hypot(x1 - x0, y1 - y0)
            num_steps = max(2, int(length_px / (self.GRID_CELL_SIZE_PX * 0.5)))
            for step in range(num_steps + 1):
                t = step / num_steps
                px = x0 + t * (x1 - x0); py = y0 + t * (y1 - y0)
                coords = self._px_to_grid(px, py)
                if coords: ground_truth.add(coords)
        return ground_truth

    def calculate_map_score(self) -> Tuple[float, float, float]:
        """Returns: (Recall, Precision, F1 Score)"""
        GT = self.ground_truth_cells; OCC = self.occupied_cells
        TP = len(OCC.intersection(GT)); FP = len(OCC.difference(GT))
        FN = len(GT.difference(OCC))
        
        recall = TP / (TP + FN) if (TP + FN) > 0 else 0.0
        precision = TP / (TP + FP) if (TP + FP) > 0 else 0.0
        f1_score = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0.0
        return recall, precision, f1_score

    def calculate_reward(self, distances_mm: List[int], distance_moved_px: float) -> float:
        """Calculates scalar reward based on wall proximity, safety, and movement."""
        FRONT_INDEX = 0; FRONT_SAFETY_MM = 500.0
        WALL_FOLLOW_INDEX = int(90.0 / DEG_PER_SAMPLE) % NUM_SAMPLES 
        target_dist_mm = self.wall_follow_distance_mm
        
        reward = 0.0
        
        if distances_mm[FRONT_INDEX] < FRONT_SAFETY_MM:
            reward -= 5.0
        else:
            reward += 0.05
            
        try:
            side_dist_mm = distances_mm[WALL_FOLLOW_INDEX]
            error_mm = abs(side_dist_mm - target_dist_mm)
            reward += math.exp(-error_mm / 300.0) * 0.5 
        except IndexError:
            pass 

        if distance_moved_px > 0:
            reward += (distance_moved_px / FEET_TO_PX) * 0.1
            
        return max(-5.0, min(5.0, reward))

    def update_map(self, distances_mm: List[int]):
        """Parses data and updates the Occupancy Grid Set."""
        lx, ly = self.world.lidar_pos; heading = self.world.lidar_heading_deg
        
        for i, mm in enumerate(distances_mm):
            dist_px = mm / FT_TO_MM * FEET_TO_PX
            angle_deg = heading - i * DEG_PER_SAMPLE
            th = math.radians(angle_deg)
            dx, dy = math.cos(th), math.sin(th)
            
            hit_x = lx + dx * dist_px
            hit_y = ly + dy * dist_px
            
            if 0 < hit_x < WORLD_PX and 0 < hit_y < WORLD_PX:
                coords = self._px_to_grid(hit_x, hit_y)
                if coords:
                    self.occupied_cells.add(coords) 

    def step(self, nn_agent: NeuralNetwork, dt: float) -> Tuple[float, float, float, float, np.ndarray]:
        """
        Runs one step of the simulation.
        Returns: (turn_rate, forward_speed_px, distance_moved_px, reward, state_arr)
        """
        distances_mm = simulate_frame(self.world)
        if not distances_mm: return 0.0, 0.0, 0.0, -5.0, np.zeros((1, NUM_SAMPLES))
        
        turn_rate, forward_speed_px = nn_agent.get_action(distances_mm)
        
        old_pos = self.world.lidar_pos
        
        heading = self.world.lidar_heading_deg + turn_rate * dt
        th = math.radians(heading)
        dx, dy = math.cos(th), math.sin(th)
        x, y = self.world.lidar_pos
        x += dx * forward_speed_px * dt 
        y += dy * forward_speed_px * dt 

        margin = LIDAR_RADIUS + WALL_THICKNESS/2 + 2
        
        collided = False
        if not (margin < x < WORLD_PX - margin and margin < y < WORLD_PX - margin):
            collided = True
            x = max(margin, min(WORLD_PX - margin, x))
            y = max(margin, min(WORLD_PX - margin, y))
            forward_speed_px = 0.0
            turn_rate = 0.0

        self.world.lidar_pos = (x, y)
        self.world.lidar_heading_deg = heading % 360.0
        
        new_pos = self.world.lidar_pos
        distance_moved_px = math.hypot(new_pos[0]-old_pos[0], new_pos[1]-old_pos[1])
        
        reward = self.calculate_reward(distances_mm, distance_moved_px)
        if collided:
             reward -= 10.0

        self.update_map(distances_mm)
        
        state_arr = np.array(distances_mm, dtype=np.float32).reshape(1, -1)
        action_arr = np.array([turn_rate / 45.0, (forward_speed_px / 300.0) * 2.0 - 1.0], dtype=np.float32).reshape(1, -1)
        self.episode_data.append((state_arr, action_arr, reward))
        
        return turn_rate, forward_speed_px, distance_moved_px, reward, state_arr

# --- 6. Main Training Loop and Execution ---

def load_initial_world() -> World:
    world = World()
    for r in SHAPES_CONFIG.get("rectangles", []):
        cx = r["cx_ft"] * FEET_TO_PX; cy = r["cy_ft"] * FEET_TO_PX
        w  = r["w_ft"]  * FEET_TO_PX; h  = r["h_ft"]  * FEET_TO_PX
        world.rectangles.append(Rectangle(cx, cy, w, h))
    for c in SHAPES_CONFIG.get("circles", []):
        cx = c["cx_ft"] * FEET_TO_PX; cy = c["cy_ft"] * FEET_TO_PX
        rr = c["r_ft"]  * FEET_TO_PX
        world.circles.append(Circle(cx, cy, rr))
    return world

def run_episode(nn_agent: NeuralNetwork, mapper: Mapper, episode_number: int, num_episodes: int) -> Tuple[float, float, float, int]:
    """Runs a single simulation and returns performance metrics and steps taken."""
    
    world_state = load_initial_world()
    start_pos_margin = WORLD_PX * 0.2
    world_state.lidar_pos = (random.uniform(start_pos_margin, WORLD_PX - start_pos_margin),
                             random.uniform(start_pos_margin, WORLD_PX - start_pos_margin))
    world_state.lidar_heading_deg = random.uniform(0.0, 360.0)
    
    mapper.reset(world_state)
    total_distance_px = 0.0
    cumulative_reward = 0.0
    steps_taken = 0

    print(f"--- Running Episode {episode_number+1}/{num_episodes}... ---", end="\r")

    for step in range(EPISODE_STEPS):
        _, _, distance_moved_px, reward, _ = mapper.step(nn_agent, DT)
        total_distance_px += distance_moved_px
        cumulative_reward += reward
        steps_taken = step + 1

        if cumulative_reward < EPISODE_CUMULATIVE_REWARD_THRESHOLD:
            print(f"--- Episode {episode_number+1} early termination: Cumulative Reward ({cumulative_reward:.2f}) below threshold ({EPISODE_CUMULATIVE_REWARD_THRESHOLD:.2f}) ---", end="\n")
            break

    total_time_s = steps_taken * DT
    avg_speed_px_s = total_distance_px / total_time_s if total_time_s > 0 else 0.0
    avg_speed_ft_s = avg_speed_px_s / FEET_TO_PX

    _, _, f1_score = mapper.calculate_map_score()
    
    WEIGHT_ACCURACY = 0.7
    WEIGHT_SPEED = 0.3
    normalized_speed = avg_speed_ft_s / 6.0
    
    weighted_score = (f1_score * WEIGHT_ACCURACY) + (normalized_speed * WEIGHT_SPEED)

    return f1_score, avg_speed_ft_s, weighted_score, steps_taken

def train_network(nn_agent: NeuralNetwork, mapper: Mapper, learning_rate: float):
    """
    OPTIMIZED: Performs vectorized batch update using Policy Gradient.
    Much faster than per-sample training.
    """
    
    if not mapper.episode_data:
        return 
        
    # Gather all data - VECTORIZED
    states_raw = np.vstack([item[0] for item in mapper.episode_data])
    actions_scaled = np.vstack([item[1] for item in mapper.episode_data])
    rewards = np.array([item[2] for item in mapper.episode_data], dtype=np.float32).reshape(-1, 1)

    # Normalize rewards
    mean_reward = np.mean(rewards)
    std_reward = np.std(rewards)
    
    if std_reward > 1e-6:
        advantage = (rewards - mean_reward) / std_reward
    else:
        advantage = (rewards - mean_reward) / 1.0 
    
    # Filter positive advantages for training
    positive_mask = advantage[:, 0] > 0.0
    
    if np.any(positive_mask):
        # OPTIMIZED: Single batch update instead of loop
        states_positive = states_raw[positive_mask]
        actions_positive = actions_scaled[positive_mask]
        advantages_positive = advantage[positive_mask]
        
        nn_agent.backward_batch(states_positive, actions_positive, advantages_positive, learning_rate)

# Main Execution
if __name__ == "__main__":
    num_episodes = 100
    start_time = time.time()
    
    INPUT_SIZE = NUM_SAMPLES
    HIDDEN_SIZE = 128
    OUTPUT_SIZE = 2
    LEARNING_RATE = 0.01  # Slightly higher LR due to momentum
    
    nn_agent = NeuralNetwork(INPUT_SIZE, HIDDEN_SIZE, OUTPUT_SIZE)
    initial_world = load_initial_world()
    mapper = Mapper(initial_world)
    
    f1_scores = []
    speed_scores = []
    weighted_scores = []
    steps_list = []
    
    highest_score_achieved = 0.0
    target_achieved_episode = -1
    
    print(f"--- Starting OPTIMIZED Neural Network Training ({num_episodes} Episodes) ---")
    
    for i in range(num_episodes):
        f1, speed, weighted_score, steps_taken = run_episode(nn_agent, mapper, i, num_episodes)
        
        train_network(nn_agent, mapper, LEARNING_RATE)
        
        f1_scores.append(f1)
        speed_scores.append(speed)
        weighted_scores.append(weighted_score)
        steps_list.append(steps_taken)
        
        if weighted_score > highest_score_achieved:
            highest_score_achieved = weighted_score

        if weighted_score >= TARGET_WEIGHTED_SCORE and target_achieved_episode == -1:
            print(f"\n--- TARGET HIT: Weighted Score ({weighted_score:.4f}) achieved in Episode {i+1} ---")
            target_achieved_episode = i + 1
        
        print(f"Episode {i+1}/{num_episodes} ({steps_taken} steps): F1={f1:.3f} | Speed={speed:.2f} ft/s | Weighted Score={weighted_score:.4f}")

    end_time = time.time()
    
    print("\n-----------------------------------------------------")
    if target_achieved_episode != -1:
        print(f"Target Weighted Score was first achieved in Episode {target_achieved_episode}.")
    else:
        print("Target Weighted Score was not reached during training.")

    print(f"Maximum episodes ({num_episodes}) reached.")
    print(f"Total Training Time: {end_time - start_time:.2f} seconds")
    print(f"Highest Weighted Score Achieved: {highest_score_achieved:.4f}")
    print("-----------------------------------------------------")
    
    # --- Plotting Results ---
    
    plt.figure(figsize=(12, 6), facecolor='#0a0f1c')
    
    ax1 = plt.gca()
    ax1.plot(weighted_scores, label='Weighted Score (70% F1, 30% Speed)', color='#e6ff6b', linewidth=3)
    
    if target_achieved_episode != -1 or TARGET_WEIGHTED_SCORE > 0:
         ax1.axhline(y=TARGET_WEIGHTED_SCORE, color='#ff6b6b', linestyle='-', linewidth=1.5, label=f'Performance Target ({TARGET_WEIGHTED_SCORE})')
    
    ax1.set_xlabel('Training Episode', color='#cdd7e7')
    ax1.set_ylabel('Weighted Score (Max 1.0)', color='#e6ff6b')
    ax1.tick_params(axis='x', colors='#cdd7e7')
    ax1.tick_params(axis='y', colors='#e6ff6b')
    
    ax2 = ax1.twinx()
    ax2.plot(f1_scores, label='F1 Score (Map Accuracy)', color='#9ec3ff', linestyle='--', alpha=0.6)
    ax2.set_ylabel('F1 Score', color='#9ec3ff')
    ax2.tick_params(axis='y', colors='#9ec3ff')
    
    ax1.set_title(f'OPTIMIZED Neural Network Performance (Batch Training + Momentum)', color='#dfe7ff', fontsize=16)
    ax1.grid(True, linestyle=':', alpha=0.3, color='#25314f')
    ax1.set_facecolor('#101729')
    
    lines, labels = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines + lines2, labels + labels2, loc='lower right', framealpha=0.7)
    
    plt.show()

    print("\n--- Final Trained Weights (W1) Sample ---")
    print(f"W1 (Input to Hidden, shape {nn_agent.W1.shape}):")
    print(f"  Mean: {np.mean(nn_agent.W1):.5f}, Max: {np.max(nn_agent.W1):.5f}")
    print(nn_agent.W1[:5, :5]) 
    
    print("\n--- Final Trained Weights (W2) Sample ---")
    print(f"W2 (Hidden to Output, shape {nn_agent.W2.shape}):")
    print(f"  Mean: {np.mean(nn_agent.W2):.5f}, Max: {np.max(nn_agent.W2):.5f}")
    print(nn_agent.W2)